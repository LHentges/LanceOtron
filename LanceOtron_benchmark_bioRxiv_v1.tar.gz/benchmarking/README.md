## Benchmarking

Each python benchmarking scripts access its assigned folder to find which peak calls to use from the "peak_calls" directory, calculates performance metrics, and writes a summary (and/or graphs) to the "results" directory. The "helper_scripts" folder has code for normalising and filtering peak calls for the TSS annotation comparisons.
